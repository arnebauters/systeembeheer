# ElastiFlow&trade; Sponsors

I have received many notes of thanks for the ElastiFlow&trade; project. However it is the generosity of sponsors and donors, that provide me the freedom to dedicate time to maintaining and further developing the solution. They also deserve not only my thanks, but also the gratitude of all ElastiFlow&trade; users.

## Donors

* TDF Cloud Services Pty Limited
* Tomislav Jambrečić
* Radek Černík
* Ian Graham
* CSIRT Gadgets, LLC
* Dmitriy Vasilets
* Robert Acquah
* Franklin Shearer
